def preprocessing_fn(inputs):
    outputs = inputs.copy()
    return outputs
